You hear a voice on the forum soundsystem: "Where did you come from?"

🎮 Player Two, write down the relative path from Fisk 109F to MFC Forum.

A “relative path” shows how to get to one file in relation to another. For example, to get from Fisk to your instructor's office, the relative path is 109/F. Or, to get from Fisk/109/F to Fisk/111, the relative path is ../../111, with double-dots taking you back up one directory.


🐇 Once complete, you look up to find words on the screen: "Go to Deering Library"
