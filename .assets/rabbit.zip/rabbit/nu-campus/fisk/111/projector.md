You arrive at the Knight Lab and realize you have downloaded yourself into your computer. 

Don't panic! It's time to find your way out - but first you need to learn how to navigate your filesystem.

Good thing you have teammates at your table. Work together to figure out how files and folders work - they are your keys to escape!

🎲 First, let's assign everyone a number:
- Check the Downloads directory on your computer.
- Sort by date to find your oldest file. 
- Each student should read that date aloud. 
- The student with the oldest file is Player One, followed by Player Two, etc. 
- Write these down on a piece of paper.

If you're not sure what to do next, you should find out. Start by looking up your instructor's office number on the syllabus, then navigate there using this filesystem. You're using the Finder app on Mac, or Explorer on Windows. No need to read any further - let's go!




⌯⌲ 
Déjà vu? If you've already seen all this, look closer: 
From Windows Explorer, View > Show > Hidden items. 
From Finder, Command + Shift + . (period) 
