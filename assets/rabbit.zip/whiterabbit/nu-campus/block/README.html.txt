<!-- 🐇 Hint: rename this file to an .html extension -->


<head>
    <script src="rabbit.js"></script>
        <style>
      body {
        margin: 0;
        height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
        background: #000;
        color: #0f0;
        font-family: "Courier New", monospace;
        font-size: 8vw; 
        text-align: center;
        white-space: pre-line; 
      }
    </style>
</head>
<body>
</body>
