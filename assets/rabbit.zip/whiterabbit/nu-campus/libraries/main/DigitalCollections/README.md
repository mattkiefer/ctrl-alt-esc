The Digital Collections room is empty but a lone computer monitor displays the instructions:

"Open the materials spreadsheet and go to cell B402. Read the last four words."

You open the spreadsheet and notice a problem. Your computer thinks it's a text file. It must be the .txt extension at the end.

You'll want .csv instead. CSV stands for comma-separated values. It allows you to build a spreadsheet table with plain text: commas indicate the start of new vertical columns and line breaks start new rows. This kind of plaintext table can be super helpful for porting data from one program to another.

But in this case, you could really use a spreadsheet tool like Excel, Numbers or Sheets to help you decipher the alphabetical column headers and numerical row labels.

To do so, you'll need to rename the file, deleting the .txt extension, and try opening it again as a csv.

Hint - if your computer can't open the csv as a spreadsheet, try importing it into Google Sheets

🎮 Player Four: What are the last four words of B402 in materials.csv? The answer reveals your next destination.
