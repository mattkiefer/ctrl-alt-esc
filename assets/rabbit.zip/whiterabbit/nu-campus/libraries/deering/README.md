Deering Library is closed, but there's a sign on the door: "Go to Digital Collections in the Main Library."

You notice a copy of William Gibson's Neuromancer by the door - probably overdue for return.  

🎮
Player Three: Move neuromancer.jpg to the main library, then write down its absolute path.

Then make your way to Digital Collections 🐇
