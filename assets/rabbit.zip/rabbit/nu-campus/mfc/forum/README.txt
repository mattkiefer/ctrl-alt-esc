You hear a voice on the forum soundsystem: "Where did you come from?"

Player Two, write down on your paper the relative path from Fisk 109F to MFC Forum.

Once complete, you look up to find words on the screen: "Go to Deering Library"
